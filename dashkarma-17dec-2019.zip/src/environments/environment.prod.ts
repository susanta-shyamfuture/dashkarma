export const environment = {
  production: true,
  apiEndpoint: "http://166.62.54.122/10karma/admin/api/",
  imageEndpoint: "http://166.62.54.122/10karma/admin/uploads/"
};
