import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SigninComponent } from '../signin/signin.component';
import { SignupComponent } from '../signup/signup.component';
import { CartComponent } from '../cart/cart.component';
import { UserService } from "../../../core/services/user.service";
import { Router } from '@angular/router';
import { MainService } from "../../../core/services/main.service";
import { environment } from "../../../../environments/environment";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  loggedIn: any;
  userName: any;
  catList: any = [];
  settingList:any={};
  imageBaseUrl: any;
  locId:any;
  customer_cart_data:any;
  cartCount:any;
  userType:any;
  constructor(
    public dialog: MatDialog,
    private router: Router,
    public userService: UserService,
    private mainService: MainService,
  ) {
    this.imageBaseUrl = environment.imageEndpoint;
    mainService.getCartNumberStatus.subscribe(status => this.cartNumberStatus(status));
    userService.getLoggedInStatus.subscribe(status => this.changeStatus(status));
  }

  ngOnInit() {
    
    this.loadUserInfo();
    this.getServicesList();
    this.getSettings();

    if (localStorage.getItem("cart")) {
      this.customer_cart_data = JSON.parse(localStorage.getItem("cart"));
      this.cartCount =  this.customer_cart_data.length;
    }
    else {
      this.customer_cart_data = [];
      this.cartCount =0;
    }
  }

  cartNumberStatus(status: boolean) {
    if (status) {
      if (localStorage.getItem("cart")) {
        this.cartCount = JSON.parse(localStorage.getItem("cart")).length;
      }
      else {
        this.cartCount = 0;
      }

   
    }
  }

  openSigninModal() {
    let dialogRef = this.dialog.open(SigninComponent, {
      width: '525px',
      data: {}
    });
    dialogRef.afterClosed().subscribe(result => {
    })
  }

  openSignupModal() {
    let dialogRef = this.dialog.open(SignupComponent, {
      width: '525px',
      data: {}
    });
    dialogRef.afterClosed().subscribe(result => {
    })
  }

  private changeStatus(status: boolean) {
    if (status) {
      //alert(0);
      this.loadUserInfo();
    }
  }

  loadUserInfo() {
    if (localStorage.getItem('isLoggedin')) {
      this.loggedIn = true;
      this.userName = localStorage.getItem('userName');
      this.userType = localStorage.getItem('userType');
    }
    else {
      this.loggedIn = false;
    }
  }

  getServicesList() {
    this.mainService.getParentCatList(0).subscribe(
      res => {
        //alert(this.keepLogin);
        console.log("Category List==>", res);
        this.catList = res['result']['list'];
      },
      error => {
        console.log(error.error);
      }
    )
  }

  getSettings() {
    this.mainService.getSettings().subscribe(
      res => {
       console.log("Settings==>",res);
       this.settingList = res['result'][0];
      },
      error => {
        console.log("Error Get Category",error);

        
      }
    )
  }

  gotoServicePage(id) {
    this.router.navigateByUrl('/services/' + id);
  }

  logOut() {
    localStorage.clear();
    this.loggedIn = false;
    this.mainService.cartNumberStatus(true);
    this.router.navigate(['/']);
  }

  gotoCart() {
    let dialogRef = this.dialog.open(CartComponent, {
      width: '900px',
      height: '900px',
      data: {}
    });
    dialogRef.afterClosed().subscribe(result => {
    })
  }

}
